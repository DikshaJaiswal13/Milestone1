package com.premium.stc.controller;

import java.sql.SQLException;

import com.premium.stc.model.User;

public interface UserController {
	public boolean registerUser(User user)throws SQLException;
	public boolean update(User user)throws SQLException;
	public boolean login(String username,String password)throws SQLException;
}
