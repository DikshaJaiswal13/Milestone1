package com.premium.stc.controller;

import java.sql.SQLException;

import com.premium.stc.model.User;
import com.premium.stc.service.UserService;
import com.premium.stc.service.UserServiceImpl;

public class UserControllerImpl implements UserController{
	UserService userService =new UserServiceImpl();

	@Override
	public boolean registerUser(User user) throws SQLException {
		userService.registerUser(user);
		return false;
	}

	@Override
	public boolean update(User user) throws SQLException {
		userService.update(user);
		return false;
	}

	@Override
	public boolean login(String username, String password) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}
	}
