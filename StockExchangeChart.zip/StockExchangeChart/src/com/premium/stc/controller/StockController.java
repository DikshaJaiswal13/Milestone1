package com.premium.stc.controller;

import java.sql.SQLException;
import java.util.List;

import com.premium.stc.model.Stock;

public interface StockController {

	public Stock insertStock(Stock stock)throws SQLException;
	public Stock updateStock(Stock stock);
	public List<Stock> getStockList()throws Exception;
}
