package com.premium.stc.controller;

import java.sql.SQLException;
import java.util.List;

import com.premium.stc.model.Stock;
import com.premium.stc.service.CompanyService;
import com.premium.stc.service.CompanyServiceImpl;
import com.premium.stc.service.StockService;
import com.premium.stc.service.StockServiceImpl;

public class StockControllerImpl implements StockController{
	private StockService stockService=new StockServiceImpl();
	@Override
	public Stock insertStock(Stock stock) throws SQLException {
		// TODO Auto-generated method stub
		stockService.insertStock(stock);
		return null;
	}

	@Override
	public Stock updateStock(Stock stock) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Stock> getStockList() throws Exception {
		// TODO Auto-generated method stub
		return stockService.getStockList();
	}

	public static void main(String args[]) {
		StockController controller=new StockControllerImpl();
		try {
			System.out.println(controller.getStockList());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
