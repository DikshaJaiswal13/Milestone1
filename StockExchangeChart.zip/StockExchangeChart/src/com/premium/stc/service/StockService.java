package com.premium.stc.service;

import java.sql.SQLException;
import java.util.List;

import com.premium.stc.model.Stock;

public interface StockService {
	public Stock insertStock(Stock stock)throws SQLException;
	public Stock updateStock(Stock stock);
	public List<Stock> getStockList()throws Exception;
}
