package com.premium.stc.service;

import com.premium.stc.model.User;

public interface UserService {
	public boolean registerUser(User user);
	public boolean update(User user);
	public boolean login(String username,String password);
}
