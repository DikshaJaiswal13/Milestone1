package com.premium.stc.service;

import java.sql.SQLException;
import java.util.List;
import com.premium.stc.dao.StockDao;
import com.premium.stc.dao.StockDaoImpl;
import com.premium.stc.model.Stock;

public class StockServiceImpl implements StockService{
	 private StockDao stockDao=new StockDaoImpl();
	@Override
	public Stock insertStock(Stock stock) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Stock updateStock(Stock stock) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Stock> getStockList() throws Exception {
		// TODO Auto-generated method stub
		return stockDao.getStockList();
	}

	

}
