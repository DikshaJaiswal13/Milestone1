package com.premium.stc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.premium.stc.model.User;

public class UserDaoImpl implements UserDao{

	@Override
	public boolean registerUser(User user) {
		boolean i=true;
		try {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/diksha","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("insert into user(username, password, usertype, email, mobilenumber, confirmed) values(?,?,?,?,?,?)");
		
		ps.setString(1,user.getUsername());
		ps.setString(2,user.getPassword());
		ps.setString(3,user.getUsertype());
		ps.setString(4,user.getEmail());
		ps.setLong(5,user.getMobilenumber());
		ps.setInt(6,user.getConfirmed());
		
		i=ps.execute();
		//System.out.println(i); returns false
		ps.close();
		conn.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean update(User user) {
		
		return false;
	}

	
	@Override
	public User login(String username, String password) {
		
		User u=new User();
		u=null;
		try {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/diksha","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("select * from user where username=? and password=?");
		ps.setString(1, username);
		ps.setString(2,password);
		ResultSet rs=ps.executeQuery();
		System.out.println(rs);
		while(rs.next()) {
			//User u=null;
			u.setId(rs.getInt(1));
			u.setUsername(rs.getString(2));
			u.setPassword(rs.getString(3));
			u.setUsertype(rs.getString(4));
			u.setEmail(rs.getString(5));
			u.setMobilenumber(rs.getInt(6));
			u.setConfirmed(rs.getInt(7));
			
		}
		ps.close();
		conn.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
		return u;
	}
	public static void main(String args[]) {
		UserDaoImpl dao=new UserDaoImpl();
		User user=new User();
		user.setUsername("diksha");
		user.setPassword("123");
		user.setUsertype("admin");
		user.setEmail("diksha@gmail.com");
		user.setMobilenumber(273738634);
		user.setConfirmed(1);
		boolean i=dao.registerUser(user);
		if(i==false)
			System.out.println("registered successfully");
			else
				System.out.println("registration error");
		User u=dao.login("diksha","123");
		if(u!=null) {
			System.out.println("login successful");
		System.out.println(u);
		}
		else
			System.out.println("Login error");
		}
	}


