package com.premium.stc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.premium.stc.model.Company;
import com.premium.stc.model.Sector;

public class CompanyDaoImpl implements CompanyDao{

	@Override
	public boolean insertCompany(Company company) {
		
		  boolean i=true; 
		  try {
			  Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/diksha","root","pass@word1");
			  PreparedStatement ps=conn.prepareStatement("insert into company(company_code,company_Name, turnover, ceo, boardofdirectors, sector_id, breifwriteup, stock_Code) values(?,?,?,?,?,?,?,?)");
			  Random r=new Random();
			  int no=r.nextInt(9000)+1000;
			  ps.setInt(1, no);
			  ps.setString(2,company.getCompanyName());
			  ps.setDouble(3,company.getTurnover());
		  ps.setString(4,company.getCeo());
		  ps.setString(5,company.getBoardOfDirectors());
		  ps.setInt(6,company.getSector().getSectorId());
		  ps.setString(7,company.getSector().getBrief());
		 
		  ps.setInt(8, no);
		  
		  i=ps.execute(); 
		  System.out.println(i); //returns false 
		  ps.close();
		  conn.close();
		  } 
		  catch(SQLException e) {
		   e.printStackTrace();
		    } 
		  return false;
		  }
		 

		
	

	@Override
	public boolean updateCompany(Company company) {
		boolean i=true;
		try {
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/diksha","root","pass@word1");
			PreparedStatement ps=conn.prepareStatement("update company set turnover=?,ceo=?,boardofdirectors=?,sector_id=?,breifwriteup=?,stock_code=? where company_code=?");
			ps.setDouble(1, company.getTurnover());
			ps.setString(2, company.getCeo());
			ps.setString(3, company.getBoardOfDirectors());
			ps.setInt(4,company.getSector().getSectorId());
			ps.setString(5,company.getSector().getBrief());
			ps.setInt(6,1009);
			ps.setInt(7,company.getCompanyId() );
			//ps.setInt(1, );
			 i=ps.execute();
			
			ps.close();
			conn.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Company> getCompanyList() throws SQLException{
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/diksha","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("select * from company");
		ResultSet rs=ps.executeQuery();
		List<Company> companyList=new ArrayList<Company>();
		Company company=null;
		while(rs.next()) {
			company=new Company();
			int companyId=rs.getInt("company_code");
			company.setCompanyId(companyId);
			company.setBoardOfDirectors(rs.getString("boardofdirectors"));
			companyList.add(company);
		}
		
		return companyList;
	}
	public static void main(String args[])throws Exception{
		CompanyDaoImpl dao=new CompanyDaoImpl();
		System.out.println(dao.getCompanyList());
		Company company=new Company();
		company.setCompanyName("TCS");
		company.setTurnover(11.5);
		company.setCeo("A.K.Das");
		company.setBoardOfDirectors("kkkkk");
		Sector sector=new Sector();
		
		sector.setSectorId(100);
		sector.setBrief("hello");
		sector.setSectorName("CTS");
		company.setSector(sector);
		//company.setCompanyId(companyId);
		boolean b=dao.insertCompany(company);
		if(b==false)
			System.out.println("Insertion successful");
		else
			System.out.println("Error in insertion");
		
		
		company.setTurnover(19.0);
		company.setCeo("A.K.D.");
		company.setBoardOfDirectors("kkfff");
		//Sector sector=new Sector();
		
		sector.setSectorId(100);
		sector.setBrief("hello");
		sector.setSectorName("CTS");
		company.setSector(sector);
		company.setCompanyId(1001);
		//company.setCompanyId(companyId);
		boolean k=dao.updateCompany(company);
		if(k==false)
			System.out.println("Updation successful");
		else
			System.out.println("Error in updation");

}
}
