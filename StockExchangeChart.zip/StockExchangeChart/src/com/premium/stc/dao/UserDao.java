package com.premium.stc.dao;

import com.premium.stc.model.User;

public interface UserDao {
	public boolean registerUser(User user);
	public boolean update(User user);
	public User login(String username,String password);
}
